package com.backend.stripeprovider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StripeProviderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
